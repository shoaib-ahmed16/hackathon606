# Backend: FastAPI service and PostgreSQL rules engine

The backend is a thin Python API over a PostgreSQL database that holds the rules. **Reads are `SELECT`s from named views; every
write calls one SQL function.** Crew legality, guardrails ("humans decide"), recommendations and the audit trail therefore live in the
database and behave identically for any client.

```
app/                 FastAPI application (about 110 endpoints under /api)
  main.py            app factory, routers, /health
  auth.py            PBKDF2 password check, HMAC-signed bearer token (expiry), roles
  db.py              psycopg 3 connection pool, per-request actor (fogops.set_actor)
  routes_read.py     flights, deadlines, crew legality, fuel, connections, exceptions ...
  routes_write.py    decisions, approvals, execute diversion, crew swap, recompute
  routes_console.py  console aggregates (briefing, flight detail, what-if)
  routes_ask.py      "Ask": suggested questions from the DB, optional Claude free text (read-only, scrubbed)
  routes_feed.py     simulated live feed push; POST /events/flight is the real integration point
  routes_*.py        cases/collab, rules, integrations, capacity, alternates, closures, weather, audit, data explorer
  worker.py          reassessment worker: LISTEN fogops_reassess, recompute as the AGENT user
  stream.py          server-sent events relay (LISTEN fogops_updated) with one-time tickets
  migrate.py         applies migrations/NNN_*.sql at start (checksummed, advisory lock)
migrations/          numbered, re-runnable schema changes (001 to 031)
fogops_db/           base schema, functions, views, reference seed, demo replay, Excel loader
db/init/             first-start restore used by docker-compose (10_fogops.sql.gz is the seeded database)
scripts/             rebuild_db.sh, make_db_dump.sh, fuel-burn fit, weather loader, fog model training
Hack606_Fog_Ops/     the organizers' input files (flights, crew duty sheets, roster, FDTL, passengers, history, GCAA rules)
```

More detail: [`API_README.md`](API_README.md) (auth, worker, audit, Ask), [`DATABASE.md`](DATABASE.md) (schema principles, migrations),
[`fogops_db/README.md`](fogops_db/README.md) (handover guide: rules, algorithms, data findings), [`../ARCHITECTURE.md`](../ARCHITECTURE.md).

## Run with Docker (recommended)

From the repository root: `cp .env.example .env`, set the secrets, then `docker compose up -d --build`. The API is on `127.0.0.1:8888`.

## Run locally without Docker for the API

Requirements: Python 3.12, PostgreSQL 16 (the compose `db` service is the easiest).

```bash
docker compose up -d db                         # from the repo root; Postgres on 127.0.0.1:5433
cd backend
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export FOGOPS_DSN=postgresql://postgres:<DB_PASSWORD>@127.0.0.1:5433/fogops
export AUTH_SECRET=$(openssl rand -hex 32)
export ENABLE_DOCS=1                            # Swagger at http://localhost:8000/docs
uvicorn app.main:app --port 8000
```

Migrations are applied automatically at start. Check `curl localhost:8000/health`.

## Configuration (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `FOGOPS_DSN` | local Postgres | connection string (`schemas fogops, hist`) |
| `AUTH_SECRET` | dev value | signs tokens. **Set a long random value outside local use** |
| `DEMO_PASSWORD` | `FogOps@2026` | initial password of the synthetic demo users |
| `TOKEN_TTL_HOURS` | 12 | token lifetime |
| `CORS_ORIGINS` | localhost:3000 | browser origins allowed to call the API directly |
| `ENABLE_DOCS` | `0` | Swagger / OpenAPI |
| `WORKER_ENABLED` | `true` | run the reassessment worker in this process |
| `WEATHER_FEED_ENABLED` | `false` | poll public METAR/TAF (aviationweather.gov, no key); stores observations only |
| `ANTHROPIC_API_KEY` | empty | enables free-text Ask. Optional: `ASK_MODEL`, `ASK_MAX_TOKENS`, `ASK_RATE_PER_MIN`, `ASK_DAILY_LIMIT` |

## Endpoint groups (all under `/api`, bearer token required except login)

| Area | Examples |
|---|---|
| Auth | `POST /auth/login`, `POST /auth/logout`, `GET /me` |
| Situation | `GET /flights`, `/deadlines`, `/briefing`, `/kpis`, `/airport/status`, `/stream` (SSE) |
| Flight | `GET /flights/{id}/detail`, `/alternates`, `/connections`, `/fuel-card`, `/timeline`, `/downstream` |
| Crew | `GET /crew/legality`, `/crew/replacement-options`, `/crew/standby-candidates`; `POST /crew/swap`, `/crew/report-time` |
| Decisions | `POST /flights/{id}/recommend`, `/decisions/{id}/approvals`, `/execute`, `/withdraw`; `GET /decisions/log` |
| Recovery | `GET /recovery/plan`, `POST /recovery/build`, `/recovery/{id}/approve` |
| What-if and cases | `POST /whatif`, `/scenarios/clone`, `/cases/create`, `/cases/{id}/close`, `/cases/{id}/report` |
| Collaboration | approvals, comments, notifications, subscriptions, data requests, custom rules |
| Capacity and weather | `GET /capacity`, `PUT /{iata}/capacity`, closure sets, external weather (labelled) |
| Audit and Ask | `GET /audit`, `POST /ask`, `GET /ask/questions` |
| Integration | `POST /events/flight` (idempotent flight events), `POST /feed/push` (simulated feed) |

Errors are JSON with a string `detail`. Database guardrail violations return 403/409, bad input 422.

## Database changes

Add `migrations/NNN_what_it_does.sql` (next number, re-runnable: `IF NOT EXISTS`, `CREATE OR REPLACE`). It is applied once, in its own
transaction, when the API starts. Never edit an applied file; add a new one. `backend/.dockerignore` excludes `*.sql` except `migrations/`; keep that exception.

## Rebuild the seed from the Excel files (optional, about 2 minutes)

```bash
export PGHOST=127.0.0.1 PGPORT=5433 PGUSER=postgres PGPASSWORD=<DB_PASSWORD>
pip install pandas openpyxl xlrd psycopg2-binary airportsdata
./fogops_db/rebuild.sh ./Hack606_Fog_Ops fogops        # schema + loader
psql -d fogops -f fogops_db/sql/05_demo_fog_replay.sql   # optional: fog replay (also an end-to-end test)
psql -d fogops -f db/init/20_cases.sql                   # one watch-list case per day of data
```

`scripts/make_db_dump.sh ./Hack606_Fog_Ops` regenerates `db/init/10_fogops.sql.gz`.

## Tests

There is no unit-test suite. The end-to-end check is `fogops_db/sql/05_demo_fog_replay.sql`, compared with `fogops_db/sql/05_demo_expected_output.txt`.
