# Foooh!: disruption control room for airline operations

Hackathon 606, Air Arabia use case 3: **fog disruption and crew duty recovery at Sharjah (SHJ)**.

When fog closes or restricts the hub, flights are held in the air or diverted, and crews can run out of legal duty hours.
Foooh! puts the facts for those decisions on one screen (time left, fuel, crew legality, alternates, connecting passengers),
recommends hold or divert with the reasons, and records every human decision and approval in an audit trail.
**The system recommends. People decide.**

| Document | What it covers |
|---|---|
| Solution Design Document (submitted as a separate PDF) | Problem, solution, key capabilities, architecture, what works in this build |
| [`ARCHITECTURE.md`](ARCHITECTURE.md) | Architecture, scalability, reliability, security, known limits |
| [`backend/README.md`](backend/README.md) | API service (FastAPI): run, configure, endpoints |
| [`backend/DATABASE.md`](backend/DATABASE.md), [`backend/fogops_db/README.md`](backend/fogops_db/README.md) | PostgreSQL schema, rules engine, migrations |
| [`hackathon-app/README.md`](hackathon-app/README.md) | Web console (React): run, structure, build |
| [`hackathon-app/docs/KT-UI-features.md`](hackathon-app/docs/KT-UI-features.md) | What each screen does, in plain language |
| [`DEPLOY_HTTPS.md`](DEPLOY_HTTPS.md) | Optional: TLS in front of the web container |

## Repository layout

```
backend/            FastAPI service, SQL schema/functions/views, numbered migrations, DB seed, loader, supplied data
hackathon-app/      React single-page app (Vite, MUI, Redux Toolkit) + nginx config and Dockerfile
docker-compose.yml  db + api + web, one command
.env.example        copy to .env and set the secrets
reset-db.sh         wipe and restore the demo database (destroys data created in the app)
```

## Run it (Docker, about 3 minutes the first time)

Requirements: Docker with Compose v2. Nothing else is needed: the database is restored from `backend/db/init/` on first start.

```bash
cp .env.example .env
# edit .env: DB_PASSWORD (letters and digits only), AUTH_SECRET (openssl rand -hex 32)
docker compose up -d --build
```

| Service | URL | Notes |
|---|---|---|
| Web console | http://localhost:8080 | nginx serves the UI and proxies `/ops-api` to the API (same origin, no CORS) |
| API | http://127.0.0.1:8888 | `GET /health` shows DB status and migration level. Set `ENABLE_DOCS=1` in `.env` for Swagger at `/docs` |
| PostgreSQL | 127.0.0.1:5433 | schemas `fogops` and `hist`; reachable from the host only |

Wait for `http://localhost:8888/health` to answer `"schema":"current"` (the first start restores about 5 MB of SQL and applies migrations).

### Sign in

Synthetic demo users; the password is `DEMO_PASSWORD` from `.env` (default `FogOps@2026`).

| User | Role | Typical use |
|---|---|---|
| `occ.dm` | OCC duty manager | decides hold/divert, approves, sets airport status |
| `dispatch.1` | Dispatch | fuel, alternates, recommendations |
| `crew.ctl.1` | Crew Control | crew legality, replacements, swaps |
| `recovery.1` | Recovery | recovery plans after reopening |
| `admin` | Admin | everything, data explorer |
| `station.rkt`, `station.fjr`, `station.aan`, `station.mct` | Station | alternate airport updates |

Set `SHOW_DEMO_USERS=true` in `.env` before building if you want the logins printed on the sign-in page.

### Optional: free-text "Ask"

Suggested questions work without any key (answered from the database). To enable free-text questions set `ANTHROPIC_API_KEY` in `.env`.
The key stays on the server; the assistant is read-only, sees no personal data and is rate limited. See `backend/API_README.md`.

## A five-minute tour

1. Sign in as `occ.dm`. The **Console** shows the flights on the active case, KPI cards, the next deadline and a "what changed" briefing.
2. Click **Push live data** to advance the simulated feed (flights depart, land, crew duty advances). Screens update by themselves (server-sent events).
3. Open an airborne flight: fuel and crew time left, ranked alternates, connecting passengers, the recommendation and its reasons.
4. Record a decision. A risky one (divert, hold, cancel) needs approval by the right second role. Sign in as `crew.ctl.1` to approve.
5. Try **What-if**: it runs in a separate scenario and never touches the live picture.
6. Open **Audit trail**: every action, including refused ones, with who and when.

## Data and safety

- All data is **synthetic or supplied by the organizers** (`backend/Hack606_Fog_Ops/`). Crew appear as position and crew number; names and phone numbers are never returned by the API.
- Anything not taken from the supplied files is labelled (`ESTIMATED`, `SIMULATED`, `ASSUMED`, `MANUAL`) and shown with its label.
- Missing or conflicting input never produces "legal": it produces `VERIFICATION_REQUIRED`, shown as "needs verification".
- No secrets are committed. `.env` is git-ignored; `.env.example` holds placeholders only.

## Rebuilding the database from the Excel files (optional)

Only needed if you want to regenerate the seed. See `backend/API_README.md` ("Run locally") and `backend/fogops_db/README.md`.
