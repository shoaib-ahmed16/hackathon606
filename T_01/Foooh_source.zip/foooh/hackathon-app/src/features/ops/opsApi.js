import { api } from '@/app/api';
import { OPS_API_URL } from '@/config/env';

// Foooh! API (FastAPI + Postgres). All reads are DB views, all actions call DB functions, so the
// rules (legality, guardrails, audit) live in one place. Docs: backend/API_README.md
const u = (path) => `${OPS_API_URL}${path}`;
const TAG = 'Ops';

const isObj = (x) => x != null && typeof x === 'object' && !Array.isArray(x);
const capList = (r) => {
  if (!Array.isArray(r)) throw new Error('Unexpected reply from the capacity service');
  return r;
};
// an assessment: stands / arrivals / occupancy / history objects and an hourly array (detail replies carry it under "assessment")
const capAssessment = (r, assessOnly) => {
  const a = assessOnly ? r.assessment : r?.assessment;
  const ok = isObj(a) && isObj(a.stands) && isObj(a.arrivals_per_hr) && isObj(a.occupancy) && isObj(a.history) && Array.isArray(a.hourly);
  if (!ok) throw new Error('Unexpected reply from the capacity service');
  return r;
};

export const opsApi = api.enhanceEndpoints({ addTagTypes: [TAG] }).injectEndpoints({
  endpoints: (build) => {
    const q = (path) =>
      build.query({ query: (params) => ({ url: u(path), params }), providesTags: [TAG] });
    const m = (fn) => build.mutation({ query: fn, invalidatesTags: [TAG] });
    return {
      getCases: q('/api/cases'),
      getScenarios: q('/api/scenarios'),
      getFlights: q('/api/flights'),
      getCrewLegality: q('/api/crew/legality'),
      getAirportStatus: q('/api/airport/status'),
      getRecoveryPlan: q('/api/recovery/plan'),
      getDiversionRecovery: q('/api/recovery/diversions'),
      getDecisionLog: q('/api/decisions/log'),
      getTimeline: q('/api/timeline'),
      getExceptions: q('/api/exceptions'),
      getFeedFreshness: q('/api/feed/freshness'),
      getStandby: q('/api/crew/standby-candidates'),
      getReplacementOptions: q('/api/crew/replacement-options'),
      getLegOutlook: q('/api/crew/leg-outlook'),
      getNextDutyLegal: q('/api/crew/next-duty-legal'),
      getN1ExtraSector: q('/api/crew/n1-extra-sector'),
      getDutySectors: q('/api/crew/duty-sectors'),
      getOpenCrewDuties: q('/api/crew/open-duties'),
      getRecOptions: q('/api/recommendations/options'),
      getDiversions: q('/api/diversions'),
      getComments: q('/api/comments'),
      getFuel: q('/api/fuel'),
      getDeadlines: q('/api/deadlines'),
      getFlightDetail: build.query({
        query: ({ flightId, ...params }) => ({ url: u(`/api/flights/${flightId}/detail`), params }),
        providesTags: [TAG],
      }),
      getBriefing: q('/api/briefing'),
      getKpis: q('/api/kpis'),
      getRuleFields: q('/api/rules/fields'),
      getIntegrations: q('/api/integrations'),
      getAlternates: build.query({
        query: ({ flightId, ...params }) => ({ url: u(`/api/flights/${flightId}/alternates`), params }),
        providesTags: [TAG],
      }),
      getDownstream: build.query({
        query: ({ flightId, ...params }) => ({ url: u(`/api/flights/${flightId}/downstream`), params }),
        providesTags: [TAG],
      }),
      // data explorer (OCC/ADMIN): the whole database, read-only
      getExplorerCatalog: build.query({ query: () => ({ url: u('/api/explorer/catalog') }), providesTags: [TAG] }),
      getExplorerRows: build.query({
        query: ({ table, limit, offset, q, sort, dir, f = [] }) => {
          const p = new URLSearchParams({ table, limit, offset, dir: dir ?? 'asc' });
          if (q) p.set('q', q);
          if (sort) p.set('sort', sort);
          f.forEach((x) => p.append('f', x));
          return { url: u(`/api/explorer/rows?${p}`) };
        },
      }),
      getExplorerLinks: build.query({ query: ({ table, row }) => ({ url: u('/api/explorer/links'), params: { table, row: JSON.stringify(row) } }) }),
      getExplorerProfile: build.query({ query: (table) => ({ url: u('/api/explorer/profile'), params: { table } }) }),
      getAlternateAirports: q('/api/alternates'),
      getConnections: build.query({ query: ({ flightId, ...params }) => ({ url: u(`/api/flights/${flightId}/connections`), params }), providesTags: [TAG] }),
      getFuelCard: build.query({ query: ({ flightId, ...params }) => ({ url: u(`/api/flights/${flightId}/fuel-card`), params }), providesTags: [TAG] }),
      getFdpPreview: q('/api/crew/fdp-preview'),
      searchAirports: q('/api/airport-search'),
      getRules: q('/api/rules'),
      getRuleMatches: q('/api/rules/matches'),
      getApprovals: q('/api/approvals'),
      getApprovalPolicy: q('/api/approval-policy'),
      getMySubscriptions: q('/api/me/subscriptions'),
      getMyNotifications: q('/api/me/notifications'),
      getDataRequests: q('/api/data-requests'),
      getFlightLinks: build.query({
        query: ({ flightId, ...params }) => ({ url: u(`/api/flights/${flightId}/links`), params }),
        providesTags: [TAG],
      }),
      getFlightTimeline: build.query({
        query: ({ flightId, ...params }) => ({
          url: u(`/api/flights/${flightId}/timeline`),
          params,
        }),
        providesTags: [TAG],
      }),
      // The capacity screens read nested fields; an unexpected reply (null, {}, an old server's shape, a proxy error page) must become an
      // ordinary query error ("could not load") and never reach the components, where it would crash the page.
      getAirportCapacity: build.query({ query: (params) => ({ url: u('/api/airports/capacity'), params }), providesTags: [TAG], transformResponse: capList }),
      getCapacityCompare: build.query({ query: (params) => ({ url: u('/api/airports/capacity/compare'), params }), providesTags: [TAG], transformResponse: capList }),
      getAirportCapacityDetail: build.query({
        query: ({ iata, ...params }) => ({ url: u(`/api/airports/${iata}/capacity`), params }),
        providesTags: [TAG],
        transformResponse: capAssessment,
      }),
      getCapacityAssess: build.query({
        query: ({ iata, ...params }) => ({
          url: u(`/api/airports/${iata}/capacity/assess`),
          params,
        }),
        providesTags: [TAG],
        transformResponse: (r) => capAssessment({ assessment: r }, true) && r,
      }),
      getAskQuestions: q('/api/ask/questions'),
      getAudit: q('/api/audit'),
      getAircraft: build.query({
        query: ({ reg, ...params }) => ({
          url: u(`/api/aircraft/${encodeURIComponent(reg)}`),
          params,
        }),
        providesTags: [TAG],
      }),

      // ---- actions
      closeCase: m(({ caseId }) => ({ url: u(`/api/cases/${caseId}/close`), method: 'POST' })),
      deleteCase: m(({ caseId }) => ({ url: u(`/api/cases/${caseId}`), method: 'DELETE' })),
      ask: m((body) => ({ url: u('/api/ask'), method: 'POST', body })),
      whatIf: m((body) => ({ url: u('/api/whatif'), method: 'POST', body })),
      approvePlan: m(({ planId }) => ({
        url: u(`/api/recovery/${planId}/approve`),
        method: 'POST',
      })),
      moveSlot: m(({ planId, flightId, body }) => ({
        url: u(`/api/recovery/${planId}/items/${flightId}`),
        method: 'PATCH',
        body,
      })),
      logoutAudit: build.mutation({
        query: () => ({ url: u('/api/auth/logout'), method: 'POST' }),
      }),
      createCase: m((body) => ({ url: u('/api/cases/create'), method: 'POST', body })),
      recommendFlight: m(({ flightId, ...params }) => ({
        url: u(`/api/flights/${flightId}/recommend`),
        method: 'POST',
        params,
      })),
      updateDiversion: m(({ id, body }) => ({
        url: u(`/api/diversions/${id}`),
        method: 'PATCH',
        body,
      })),
      setAirportCapacity: m(({ iata, body }) => ({
        url: u(`/api/airports/${iata}/capacity`),
        method: 'PUT',
        body,
      })),
      pushFeed: m((body) => ({ url: u('/api/feed/push'), method: 'POST', body: body ?? {} })),
      flightEvent: m((body) => ({ url: u('/api/events/flight'), method: 'POST', body })),
      addRecord: m(({ table, body }) => ({
        url: u(`/api/records/${table}`),
        method: 'POST',
        body,
      })),
      executeDiversion: m(({ decisionId }) => ({
        url: u(`/api/decisions/${decisionId}/execute-diversion`),
        method: 'POST',
      })),
      executeDecision: m(({ decisionId }) => ({ url: u(`/api/decisions/${decisionId}/execute`), method: 'POST' })),
      saveAlternate: m((body) => ({ url: u('/api/alternates'), method: 'POST', body })),
      createStationLogin: m(({ alt }) => ({ url: u(`/api/alternates/${alt}/station-login`), method: 'POST' })),
      withdrawDecision: m(({ decisionId, reason }) => ({ url: u(`/api/decisions/${decisionId}/withdraw`), method: 'POST', body: { reason } })),
      setScenarioClock: m(({ id, ...body }) => ({ url: u(`/api/scenarios/${id}/clock`), method: 'POST', body })),
      moveReportTime: m((body) => ({ url: u('/api/crew/report-time'), method: 'POST', body })),
      patchSystem: m(({ code, ...body }) => ({ url: u(`/api/integrations/systems/${code}`), method: 'PATCH', body })),
      markEntered: m(({ id }) => ({ url: u(`/api/integrations/outbox/${id}/entered`), method: 'POST' })),
      addTag: m(({ flightId, ...body }) => ({ url: u(`/api/flights/${flightId}/tags`), method: 'POST', body })),
      removeTag: m(({ flightId, tag, ...params }) => ({ url: u(`/api/flights/${flightId}/tags/${tag}`), method: 'DELETE', params })),
      createRule: m((body) => ({ url: u('/api/rules'), method: 'POST', body })),
      approveRule: m(({ id }) => ({ url: u(`/api/rules/${id}/approve`), method: 'POST' })),
      rejectRule: m(({ id }) => ({ url: u(`/api/rules/${id}/reject`), method: 'POST' })),
      retireRule: m(({ id }) => ({ url: u(`/api/rules/${id}/retire`), method: 'POST' })),
      // preview does not change anything, so it must not refetch the whole console on every keystroke
      previewRule: build.mutation({
        query: (body) => ({ url: u('/api/rules/preview'), method: 'POST', body }),
      }),
      sendVerdict: m(({ decisionId, ...body }) => ({
        url: u(`/api/decisions/${decisionId}/approvals`),
        method: 'POST',
        body,
      })),
      subscribe: m(({ flightId, ...body }) => ({
        url: u(`/api/flights/${flightId}/subscriptions`),
        method: 'POST',
        body,
      })),
      unsubscribe: m(({ flightId, ...params }) => ({
        url: u(`/api/flights/${flightId}/subscriptions`),
        method: 'DELETE',
        params,
      })),
      readNotification: m(({ id }) => ({ url: u(`/api/notifications/${id}/read`), method: 'POST' })),
      readAllNotifications: m(() => ({ url: u('/api/me/notifications/read-all'), method: 'POST' })),
      askForData: m(({ flightId, ...body }) => ({
        url: u(`/api/flights/${flightId}/data-requests`),
        method: 'POST',
        body,
      })),
      answerData: m(({ requestId, ...body }) => ({
        url: u(`/api/data-requests/${requestId}/answer`),
        method: 'POST',
        body,
      })),
      swapCrew: m((body) => ({ url: u('/api/crew/swap'), method: 'POST', body })),
      recomputeFlight: m(({ flightId, scenario_id }) => ({
        url: u(`/api/flights/${flightId}/recompute`),
        method: 'POST',
        params: { scenario_id },
      })),
      buildRecovery: m((body) => ({ url: u('/api/recovery/build'), method: 'POST', body })),
      generateReport: m(({ caseId }) => ({
        url: u(`/api/cases/${caseId}/report`),
        method: 'POST',
      })),
    };
  },
});

export const {
  useGetCasesQuery,
  useGetFlightsQuery,
  useGetCrewLegalityQuery,
  useGetAirportStatusQuery,
  useGetRecoveryPlanQuery,
  useGetDecisionLogQuery,
  useGetTimelineQuery,
  useGetExceptionsQuery,
  useGetFeedFreshnessQuery,
  useGetStandbyQuery,
  useGetReplacementOptionsQuery,
  useGetLegOutlookQuery,
  useGetNextDutyLegalQuery,
  useGetN1ExtraSectorQuery,
  useGetDutySectorsQuery,
  useGetOpenCrewDutiesQuery,
  useGetAircraftQuery,
  useGetDeadlinesQuery,
  useGetFlightDetailQuery,
  useGetBriefingQuery,
  useGetAirportCapacityQuery,
  useGetAirportCapacityDetailQuery,
  useGetCapacityAssessQuery,
  useGetCapacityCompareQuery,
  useSetAirportCapacityMutation,
  useGetAskQuestionsQuery,
  useGetAuditQuery,
  useGetKpisQuery,
  useGetRuleFieldsQuery,
  useGetIntegrationsQuery,
  useGetAlternatesQuery,
  useGetExplorerCatalogQuery,
  useGetExplorerRowsQuery,
  useGetExplorerLinksQuery,
  useGetExplorerProfileQuery,
  useGetDownstreamQuery,
  useExecuteDecisionMutation,
  usePatchSystemMutation,
  useSetScenarioClockMutation,
  useMoveReportTimeMutation,
  useWithdrawDecisionMutation,
  useGetAlternateAirportsQuery,
  useGetConnectionsQuery,
  useGetFuelCardQuery,
  useGetFdpPreviewQuery,
  useSearchAirportsQuery,
  useSaveAlternateMutation,
  useCreateStationLoginMutation,
  useMarkEnteredMutation,
  useAddTagMutation,
  useRemoveTagMutation,
  useGetRulesQuery,
  useGetRuleMatchesQuery,
  useCreateRuleMutation,
  useApproveRuleMutation,
  useRejectRuleMutation,
  useRetireRuleMutation,
  usePreviewRuleMutation,
  useGetApprovalsQuery,
  useGetApprovalPolicyQuery,
  useGetMySubscriptionsQuery,
  useGetMyNotificationsQuery,
  useGetDataRequestsQuery,
  useGetFlightLinksQuery,
  useGetFlightTimelineQuery,
  useSendVerdictMutation,
  useSubscribeMutation,
  useUnsubscribeMutation,
  useReadNotificationMutation,
  useReadAllNotificationsMutation,
  useAskForDataMutation,
  useAnswerDataMutation,
  useAskMutation,
  usePushFeedMutation,
  useWhatIfMutation,
  useApprovePlanMutation,
  useMoveSlotMutation,
  useLogoutAuditMutation,
  useGetScenariosQuery,
  useCreateCaseMutation,
  useCloseCaseMutation,
  useDeleteCaseMutation,
  useGetRecOptionsQuery,
  useGetDiversionsQuery,
  useGetDiversionRecoveryQuery,
  useGetCommentsQuery,
  useGetFuelQuery,
  useRecommendFlightMutation,
  useUpdateDiversionMutation,
  useFlightEventMutation,
  useAddRecordMutation,
  useExecuteDiversionMutation,
  useSwapCrewMutation,
  useRecomputeFlightMutation,
  useBuildRecoveryMutation,
  useGenerateReportMutation,
} = opsApi;
