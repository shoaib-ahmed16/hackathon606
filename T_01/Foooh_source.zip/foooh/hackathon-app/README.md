# Foooh! web console (React)

Single-page app for the disruption control room. It computes nothing operational: legality, deadlines, options and recommendations
come from the API (which reads database views). The UI shows them, records human decisions and refreshes live from a server-sent event stream.

**Stack:** React 19, Vite, Redux Toolkit + RTK Query, React Router 7, MUI 9, react-hook-form + zod, date-fns, plain CSS design tokens (dark and light). Desktop first (1024 px and up).

## Run

Easiest: from the repository root, `docker compose up -d --build`, then open http://localhost:8080 (see the root README for sign-in users).

Development server (Node 22.12+, Node 24 recommended; `.nvmrc` is provided):

```bash
cd hackathon-app
nvm use
npm ci
cp .env.example .env        # VITE_OPS_API_URL=http://localhost:8000 (the API must be running, see backend/README.md)
npm run dev                 # http://localhost:3000
```

| Command | What it does |
|---|---|
| `npm run dev` | dev server on port 3000 |
| `npm run build` | production build into `dist/` |
| `npm run lint` | ESLint |
| `npm run check` | lint + build |
| `npm run format` | Prettier |

## Configuration (build time)

| Variable | Meaning |
|---|---|
| `VITE_OPS_API_URL` | API base. Docker build uses `/ops-api` (nginx proxies it to the API on the same origin, so no CORS) |
| `VITE_SHOW_DEMO_USERS` | `true` prints the demo logins on the sign-in page (demo builds only) |

Values are baked into the bundle at build time; the Dockerfile takes them as build arguments.

## Screens

| Route | Page |
|---|---|
| `/` | **Console board**: KPI cards, filters, flight lanes, flight panel (fuel, crew, alternates, connections, recommendation, decisions), what-if, briefing, Ask chat |
| `/alternates` | Alternate airports manager, ranked options, station updates |
| `/capacity` | Airport capacity (stands, arrivals per hour) and assessment per flight |
| `/rules` | Custom alert and approval rules (preview before saving) |
| `/integrations` | External systems and outbox |
| `/data-quality` | Data exceptions and "needs verification" items |
| `/audit`, `/reports` | Audit trail; decision counts and reports |
| `/data` | Read-only data explorer (OCC and admin only) |
| `/login` | Sign in |

Plain-language description of every screen: [`docs/KT-UI-features.md`](docs/KT-UI-features.md).

## Structure

```
src/
  app/          store.js, api.js (single RTK Query api: auth header, auto-logout on 401), hooks
  features/     auth, ops (opsApi.js endpoints, opsSlice.js state, useOps.js hooks, refresh.js live refresh), ui
  console/      the control room: ConsoleLayout, board/, panel/, lenses/ (role views), sheets/ (decision dialogs), drawers/, pages/
  pages/        route-level pages outside the console shell (Login, Audit, Data explorer ...)
  components/   shared blocks (PageHeader, StatCard, ErrorBoundary, capacity/, form/ ...)
  routes/       route table (lazy-loaded pages) and ProtectedRoute
  theme/        colors and typography tokens
  config/       env.js (the only place env vars are read), brand, navigation
```

## Behaviour worth knowing

- **Live updates:** the app opens `/api/stream` (SSE, one-time ticket) and refetches affected views; it falls back to 10 s polling if the stream drops.
- **Time:** all times are UTC from the server, shown as `HH:MMZ / HH:MM SHJ`; countdowns use the scenario clock supplied by the API, never the browser clock.
- **Roles:** the UI hides what a role cannot do, but the database enforces it; a refused action shows the server's message.
- **Unknowns stay unknown:** missing values show as "needs verification", and quality labels (`ESTIMATED`, `SIMULATED`, `ASSUMED`) are displayed with the number.

## Production image

`Dockerfile`: Node build stage, then nginx serving `dist/` with security headers (`security-headers.conf`) and the `/ops-api` reverse proxy (`nginx.conf`).
