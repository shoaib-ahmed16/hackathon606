-- =====================================================================
-- FOOH / FogOps database validation
--   psql "$FOGOPS_DSN" -f db_validation.sql > db_validation_report.txt
-- Read-only for your data: every write test runs inside a sub-transaction that is rolled back.
-- Output: one row per check: area | check | PASS / WARN / FAIL / SKIP | detail
-- =====================================================================
\pset pager off
\set ON_ERROR_STOP off
SET client_min_messages = warning;
SET search_path = fogops, public;

DROP TABLE IF EXISTS pg_temp.vr;
CREATE TEMP TABLE vr (id SERIAL, area TEXT, check_name TEXT, status TEXT, detail TEXT);
CREATE OR REPLACE FUNCTION pg_temp.chk(a TEXT, n TEXT, ok BOOLEAN, d TEXT, warn_only BOOLEAN DEFAULT FALSE)
RETURNS VOID LANGUAGE sql AS $$
  INSERT INTO vr(area, check_name, status, detail)
  VALUES (a, n, CASE WHEN ok IS NULL THEN 'SKIP' WHEN ok THEN 'PASS' WHEN warn_only THEN 'WARN' ELSE 'FAIL' END, d) $$;

-- ---------------------------------------------------------------------
-- 1. Structure
-- ---------------------------------------------------------------------
SELECT pg_temp.chk('1 structure', 'core tables present',
  (SELECT count(*) FROM unnest(ARRAY['airport','alternate_airport','aircraft','crew_type','rule_set','fdp_rule','flight','flight_event',
     'flight_state','airport_status_event','crew_member','crew_qualification','crew_duty','crew_duty_leg','crew_assignment','roster_entry',
     'standby_slot','fdp_calculation','latest_departure_calc','recommendation','recommendation_option','decision','decision_approval',
     'diversion','crew_replacement','recovery_plan','recovery_plan_item','case_comment','data_exception','audit_log','reassessment_queue',
     'report','pax_connection','scenario','disruption_case','case_flight','app_user','app_role']) t
   WHERE to_regclass('fogops.'||t) IS NULL) = 0,
  'missing: ' || coalesce((SELECT string_agg(t, ', ') FROM unnest(ARRAY['airport','flight','flight_state','crew_duty','crew_duty_leg',
     'crew_assignment','fdp_calculation','recommendation','decision','decision_approval','diversion','audit_log','pax_connection']) t
   WHERE to_regclass('fogops.'||t) IS NULL), 'none'));
SELECT pg_temp.chk('1 structure', 'frontend views present',
  (SELECT count(*) FROM unnest(ARRAY['v_flight_watch','v_crew_legality_ranking','v_aircraft_whereabouts','v_recommendation_options',
     'v_recovery_plan_current','v_case_timeline','v_decision_log','v_airport_status_current','v_open_exceptions','v_connection_risk']) v
   WHERE to_regclass('fogops.'||v) IS NULL) = 0,
  'missing: ' || coalesce((SELECT string_agg(v, ', ') FROM unnest(ARRAY['v_flight_watch','v_crew_legality_ranking','v_aircraft_whereabouts',
     'v_recommendation_options','v_recovery_plan_current','v_case_timeline','v_decision_log','v_airport_status_current','v_open_exceptions',
     'v_connection_risk']) v WHERE to_regclass('fogops.'||v) IS NULL), 'none'));
SELECT pg_temp.chk('1 structure', 'engine functions present',
  (SELECT count(*) FROM unnest(ARRAY['ingest_flight_event','compute_duty_legality','compute_flight_legality','compute_latest_departure',
     'propose_hold_or_divert','rank_alternates','execute_diversion','swap_crew','standby_candidates','build_recovery_plan','generate_report',
     'clone_scenario','set_actor','scenario_now','flight_lvp_check']) fn
   WHERE NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='fogops' AND p.proname=fn)) = 0,
  'missing: ' || coalesce((SELECT string_agg(fn, ', ') FROM unnest(ARRAY['ingest_flight_event','compute_duty_legality','propose_hold_or_divert',
     'rank_alternates','execute_diversion','swap_crew','standby_candidates','build_recovery_plan','generate_report','clone_scenario',
     'flight_lvp_check']) fn
   WHERE NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='fogops' AND p.proname=fn)), 'none'));
SELECT pg_temp.chk('1 structure', 'latest fixes present (time-base TB-1..5, downstream impact)',
  EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='fogops' AND p.proname='downstream_impact')
  AND EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='fogops' AND table_name='v_crew_legality_ranking' AND column_name='duty_started'),
  'needs the latest 02_functions_triggers.sql + 03_views.sql (downstream_impact, duty_started)');
SELECT pg_temp.chk('1 structure', 'MVP extensions 06/07 applied',
  to_regclass('fogops.approval_policy') IS NOT NULL AND to_regclass('fogops.flight_subscription') IS NOT NULL
  AND to_regclass('fogops.notification_outbox') IS NOT NULL AND to_regclass('fogops.integration_outbox') IS NOT NULL,
  'optional for the demo; needed for multi-role approval, subscriptions, notifications, aeroMart outbox', TRUE);
SELECT pg_temp.chk('1 structure', 'function search_path pinned',
  (SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
    WHERE n.nspname='fogops' AND (p.proconfig IS NULL OR NOT EXISTS (SELECT 1 FROM unnest(p.proconfig) c WHERE c LIKE 'search_path=%'))) = 0,
  (SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
    WHERE n.nspname='fogops' AND (p.proconfig IS NULL OR NOT EXISTS (SELECT 1 FROM unnest(p.proconfig) c WHERE c LIKE 'search_path=%')))
  || ' functions without pinned search_path (re-run the pinning DO block at the end of 02)', TRUE);
SELECT pg_temp.chk('1 structure', 'guardrail triggers present',
  (SELECT count(DISTINCT tgname) FROM pg_trigger WHERE tgname IN ('decision_guard','decision_approval_apply','rule_set_guard','fdp_rule_guard',
     'audit_log_append_only','flight_event_guard','airport_status_append_only','audit_decision')) = 8,
  (SELECT string_agg(tgname, ', ') FROM pg_trigger WHERE tgname IN ('decision_guard','decision_approval_apply','rule_set_guard','fdp_rule_guard',
     'audit_log_append_only','flight_event_guard','airport_status_append_only','audit_decision')));

-- ---------------------------------------------------------------------
-- 2. Reference data and confirmed business rules
-- ---------------------------------------------------------------------
SELECT pg_temp.chk('2 reference', 'exactly one approved, open-ended FDP rule set',
  (SELECT count(*) FROM rule_set WHERE status='APPROVED' AND effective_to IS NULL) = 1,
  (SELECT string_agg(name||' '||version||' ('||status||')', '; ') FROM rule_set));
SELECT pg_temp.chk('2 reference', 'FDP bands on SHJ local time (organizer rule)',
  (SELECT band_reference='FIXED_TZ' AND band_tz='Asia/Dubai' FROM rule_set WHERE status='APPROVED' AND effective_to IS NULL),
  (SELECT band_reference||' '||coalesce(band_tz,'') FROM rule_set WHERE status='APPROVED' AND effective_to IS NULL));
SELECT pg_temp.chk('2 reference', '216 FDP rules loaded from Crew_FDTL', (SELECT count(*) FROM fdp_rule fr JOIN rule_set rs USING (rule_set_id) WHERE rs.status='APPROVED') = 216,
  (SELECT count(*) FROM fdp_rule)::text || ' rules');
SELECT pg_temp.chk('2 reference', 'commander discretion = 180 min', (SELECT commander_discretion_min FROM rule_set WHERE status='APPROVED' AND effective_to IS NULL) = 180, '');
SELECT pg_temp.chk('2 reference', 'LVP required for CP and FO (organizer rule)',
  (SELECT bool_and(requires_lvp) FROM crew_type WHERE code IN ('CP','FO')) AND NOT (SELECT bool_or(requires_lvp) FROM crew_type WHERE code IN ('CS','CC')), '');
SELECT pg_temp.chk('2 reference', 'all airports have a valid IANA timezone', (SELECT count(*) FROM airport WHERE tz IS NULL OR tz='') = 0, (SELECT count(*) FROM airport)::text || ' airports');
SELECT pg_temp.chk('2 reference', 'SHJ alternates configured (6)', (SELECT count(*) FROM alternate_airport WHERE hub_iata='SHJ' AND is_active) >= 6,
  (SELECT string_agg(alt_iata, ',' ORDER BY priority) FROM alternate_airport WHERE hub_iata='SHJ'));
SELECT pg_temp.chk('2 reference', 'return block times for alternates', (SELECT count(*) FROM block_time_reference WHERE to_iata='SHJ' AND from_iata IN (SELECT alt_iata FROM alternate_airport WHERE hub_iata='SHJ')) >= 6,
  (SELECT string_agg(from_iata||' '||p90_block_min||'m', ', ') FROM block_time_reference WHERE to_iata='SHJ' AND from_iata IN ('RKT','FJR','AAN','DWC','AUH','MCT')));
SELECT pg_temp.chk('2 reference', 'human roles can approve, AGENT cannot',
  (SELECT bool_and(can_approve) FROM app_role WHERE code IN ('OCC','DISPATCH','CREW_CONTROL')) AND NOT (SELECT is_human OR can_approve FROM app_role WHERE code='AGENT'), '');
SELECT pg_temp.chk('2 reference', 'users exist for OCC, DISPATCH, CREW_CONTROL, STATION, AGENT',
  (SELECT count(DISTINCT role_code) FROM app_user WHERE is_active AND role_code IN ('OCC','DISPATCH','CREW_CONTROL','STATION','AGENT')) = 5,
  (SELECT string_agg(DISTINCT role_code, ',') FROM app_user WHERE is_active));

-- ---------------------------------------------------------------------
-- 3. Data integrity
-- ---------------------------------------------------------------------
SELECT pg_temp.chk('3 data', 'flights: STA after STD', (SELECT count(*) FROM flight WHERE sta_utc <= std_utc) = 0, '');
SELECT pg_temp.chk('3 data', 'no duplicate flights (same number+route within 6 h)',
  (SELECT count(*) FROM flight a JOIN flight b ON a.flight_no=b.flight_no AND a.dep_iata=b.dep_iata AND a.arr_iata=b.arr_iata
     AND a.flight_id < b.flight_id AND abs(extract(epoch FROM a.std_utc-b.std_utc)) < 6*3600 AND a.flight_kind<>'RECOVERY' AND b.flight_kind<>'RECOVERY') = 0,
  (SELECT count(*) FROM flight a JOIN flight b ON a.flight_no=b.flight_no AND a.dep_iata=b.dep_iata AND a.arr_iata=b.arr_iata
     AND a.flight_id < b.flight_id AND abs(extract(epoch FROM a.std_utc-b.std_utc)) < 6*3600 AND a.flight_kind<>'RECOVERY' AND b.flight_kind<>'RECOVERY')::text
   || ' pairs (fix: loader links duty-sheet legs with revised times to the rotation flight)');
SELECT pg_temp.chk('3 data', 'every flight has a LIVE state row',
  (SELECT count(*) FROM flight f WHERE f.flight_kind<>'RECOVERY' AND NOT EXISTS (SELECT 1 FROM flight_state s WHERE s.scenario_id=1 AND s.flight_id=f.flight_id)) = 0,
  (SELECT count(*) FROM flight f WHERE f.flight_kind<>'RECOVERY' AND NOT EXISTS (SELECT 1 FROM flight_state s WHERE s.scenario_id=1 AND s.flight_id=f.flight_id))::text || ' without state');
SELECT pg_temp.chk('3 data', 'status consistent with actual times (LIVE)',
  (SELECT count(*) FROM flight_state s JOIN flight f USING (flight_id) WHERE s.scenario_id=1 AND s.status <> derive_flight_status(s, f.arr_iata)) = 0,
  (SELECT count(*) FROM flight_state s JOIN flight f USING (flight_id) WHERE s.scenario_id=1 AND s.status <> derive_flight_status(s, f.arr_iata))::text || ' mismatches');
SELECT pg_temp.chk('3 data', 'no "airborne" flight before its STD-2h or after ATA (LIVE)',
  (SELECT count(*) FROM flight_state s JOIN flight f USING (flight_id) WHERE s.scenario_id=1 AND s.status IN ('AIRBORNE','HOLDING')
     AND (scenario_now(1) < f.std_utc - interval '2 hours' OR s.ata_utc IS NOT NULL)) = 0,
  'catches flights shown airborne a day early (e.g. G9822 21 Nov shown airborne on 20 Nov)');
SELECT pg_temp.chk('3 data', 'every duty has legs and crew',
  (SELECT count(*) FROM crew_duty d WHERE NOT EXISTS (SELECT 1 FROM crew_assignment a WHERE a.duty_id=d.duty_id AND a.scenario_id=1)) <= 1,
  (SELECT count(*) FROM crew_duty d WHERE NOT EXISTS (SELECT 1 FROM crew_assignment a WHERE a.duty_id=d.duty_id AND a.scenario_id=1))::text
   || ' duties without crew (1 expected in the supplied data)', TRUE);
SELECT pg_temp.chk('3 data', 'duty-sheet-only flights are genuinely missing from the rotation (no twin within 6 h)',
  (SELECT count(*) FROM flight d JOIN flight r ON r.flight_no=d.flight_no AND r.dep_iata=d.dep_iata AND r.flight_id<>d.flight_id
     AND abs(extract(epoch FROM d.std_utc-r.std_utc)) < 6*3600 WHERE d.source LIKE 'duty_sheet:%') = 0,
  (SELECT count(*) FROM flight WHERE source LIKE 'duty_sheet:%')::text || ' created from duty sheets');
SELECT pg_temp.chk('3 data', 'crew legs inside their duty window (sign-in -1 h .. +20 h)',
  (SELECT count(*) FROM crew_duty d JOIN crew_duty_leg l ON l.duty_id=d.duty_id AND l.scenario_id=1 JOIN flight f ON f.flight_id=l.flight_id
     WHERE d.sign_in_utc IS NOT NULL AND (f.std_utc < d.sign_in_utc - interval '1 hour' OR f.std_utc > d.sign_in_utc + interval '20 hours')) = 0,
  (SELECT count(*) FROM crew_duty d JOIN crew_duty_leg l ON l.duty_id=d.duty_id AND l.scenario_id=1 JOIN flight f ON f.flight_id=l.flight_id
     WHERE d.sign_in_utc IS NOT NULL AND (f.std_utc < d.sign_in_utc - interval '1 hour' OR f.std_utc > d.sign_in_utc + interval '20 hours'))::text || ' legs outside their duty');
SELECT pg_temp.chk('3 data', 'one active assignment per crew per duty',
  (SELECT count(*) FROM (SELECT scenario_id, duty_id, crew_id FROM crew_assignment WHERE valid_to IS NULL GROUP BY 1,2,3 HAVING count(*)>1) x) = 0, '');
SELECT pg_temp.chk('3 data', 'roster converted from SHJ local (UTC = local - 4 h)',
  (SELECT count(*) FROM roster_entry WHERE start_utc <> (start_local AT TIME ZONE 'Asia/Dubai')) = 0,
  (SELECT count(*) FROM roster_entry WHERE start_utc <> (start_local AT TIME ZONE 'Asia/Dubai'))::text || ' rows not on SHJ local');
SELECT pg_temp.chk('3 data', 'connecting pax direction (inbound arrives where outbound departs)',
  (SELECT count(*) FROM pax_connection pc JOIN flight fi ON fi.flight_id=pc.inbound_flight_id JOIN flight fo ON fo.flight_id=pc.outbound_flight_id
     WHERE fi.arr_iata <> fo.dep_iata OR fo.std_utc <= fi.sta_utc) = 0,
  (SELECT count(*) FROM pax_connection)::text || ' connections, '
   || (SELECT count(*) FROM pax_connection pc JOIN flight fi ON fi.flight_id=pc.inbound_flight_id JOIN flight fo ON fo.flight_id=pc.outbound_flight_id
       WHERE fi.arr_iata <> fo.dep_iata OR fo.std_utc <= fi.sta_utc)::text || ' reversed/invalid');
SELECT pg_temp.chk('3 data', 'connecting pax not double counted (expected ~31.5k for 20-23 Nov)',
  (SELECT sum(pax_count) FROM pax_connection) BETWEEN 25000 AND 40000, (SELECT sum(pax_count) FROM pax_connection)::text || ' pax');
SELECT pg_temp.chk('3 data', 'feed freshness visible', (SELECT count(*) FROM feed_source WHERE last_received_at IS NOT NULL) >= 1,
  (SELECT string_agg(source_code||' '||coalesce(to_char(last_received_at,'DD HH24:MI'),'never'), ', ') FROM feed_source));

-- ---------------------------------------------------------------------
-- 4. Crew legality (reference cases)
-- ---------------------------------------------------------------------
SELECT pg_temp.chk('4 legality', 'every duty has a current LIVE result',
  (SELECT count(*) FROM crew_duty d WHERE NOT EXISTS (SELECT 1 FROM fdp_calculation c WHERE c.scenario_id=1 AND c.duty_id=d.duty_id AND c.is_current AND c.crew_id IS NULL)) = 0,
  (SELECT string_agg(status||'='||n, ', ') FROM (SELECT status::text, count(*) n FROM fdp_calculation WHERE scenario_id=1 AND is_current AND crew_id IS NULL GROUP BY 1) x));
SELECT pg_temp.chk('4 legality', 'reference: G9070/G9071 SHJ-ELQ-SHJ 21 Nov captain legal end 11:05Z (rule 42, 10:15)',
  EXISTS (SELECT 1 FROM fdp_calculation c JOIN crew_duty_leg l ON l.duty_id=c.duty_id AND l.scenario_id=1 JOIN flight f ON f.flight_id=l.flight_id
          WHERE c.scenario_id=1 AND c.is_current AND c.position_code='CP' AND f.flight_no='G9071' AND f.std_utc::date='2026-11-21'
            AND c.legal_end_utc='2026-11-21 11:05Z' AND c.max_fdp_min=615), '');
SELECT pg_temp.chk('4 legality', 'reference: G9822 BKK-SHJ 21 Nov crew legal end 11:20Z, 1 sector',
  EXISTS (SELECT 1 FROM fdp_calculation c JOIN crew_duty_leg l ON l.duty_id=c.duty_id AND l.scenario_id=1 JOIN flight f ON f.flight_id=l.flight_id
          WHERE c.scenario_id=1 AND c.is_current AND c.crew_id IS NULL AND f.flight_no='G9822' AND f.std_utc='2026-11-21 01:20Z'
            AND c.legal_end_utc='2026-11-21 11:20Z' AND c.legs_counted=1), '');
SELECT pg_temp.chk('4 legality', 'no LEGAL result without a rule',
  (SELECT count(*) FROM fdp_calculation WHERE is_current AND status='LEGAL' AND rule_id IS NULL AND crew_id IS NOT NULL) = 0, '');
SELECT pg_temp.chk('4 legality', 'duties with SO crew are VERIFICATION_REQUIRED (no SO rule supplied)',
  (SELECT count(*) FROM fdp_calculation c WHERE c.scenario_id=1 AND c.is_current AND c.crew_id IS NULL AND c.status <> 'VERIFICATION_REQUIRED'
     AND EXISTS (SELECT 1 FROM crew_assignment a WHERE a.duty_id=c.duty_id AND a.scenario_id=1 AND a.valid_to IS NULL AND a.position_code='SO')) = 0, '');
SELECT pg_temp.chk('4 legality', 'margins plausible (|margin| < max FDP + discretion)',
  (SELECT count(*) FROM fdp_calculation WHERE is_current AND margin_min IS NOT NULL AND abs(margin_min) > coalesce(max_fdp_min,0) + 180) = 0,
  (SELECT count(*) FROM fdp_calculation WHERE is_current AND margin_min IS NOT NULL AND abs(margin_min) > coalesce(max_fdp_min,0) + 180)::text || ' implausible');
SELECT pg_temp.chk('4 legality', 'latest legal departure never before crew sign-in',
  (SELECT count(*) FROM latest_departure_calc ld JOIN fdp_calculation c ON c.calc_id = ld.fdp_calc_id
     WHERE ld.is_current AND ld.latest_legal_offblocks_utc < c.sign_in_utc) = 0, '');

-- ---------------------------------------------------------------------
-- 5. Time base (the G9822 class of bug)
-- ---------------------------------------------------------------------
DO $$
DECLARE f BIGINT; r RECORD; bad INT := 0; mx INT := 0; n INT := 0; i RECORD;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname='flight_decision_inputs') THEN
     PERFORM pg_temp.chk('5 time base','decision inputs available', NULL, 'flight_decision_inputs() missing'); RETURN; END IF;
  -- not-departed SHJ arrivals: options must be anchored at arrival, margins bounded, no time-base errors
  FOR f IN SELECT fl.flight_id FROM flight fl JOIN flight_state s ON s.flight_id=fl.flight_id AND s.scenario_id=1
            WHERE fl.arr_iata='SHJ' AND s.status='SCHEDULED' AND fl.std_utc > scenario_now(1) ORDER BY fl.std_utc LIMIT 15 LOOP
    n := n + 1;
    SELECT * INTO i FROM flight_decision_inputs(1, f);
    IF i.anchor_utc < (SELECT sta_utc FROM flight WHERE flight_id=f) - interval '2 hours' THEN bad := bad + 1; END IF;
    FOR r IN SELECT * FROM rank_alternates(1, f) LOOP
      mx := greatest(mx, coalesce(r.crew_return_margin_min, 0));
      IF r.blocking_constraints::text LIKE '%TIME_BASE_INCONSISTENT%' THEN bad := bad + 1; END IF;
    END LOOP;
  END LOOP;
  PERFORM pg_temp.chk('5 time base', 'not-departed flights assessed at arrival, not at "now" (TB-1/TB-2)', bad = 0,
    n || ' flights checked, ' || bad || ' anchored wrongly');
  PERFORM pg_temp.chk('5 time base', 'crew return margins bounded (no 963-min type values)', mx < 14*60,
    'max crew return margin ' || mx || ' min');
EXCEPTION WHEN others THEN PERFORM pg_temp.chk('5 time base','time-base checks ran', FALSE, SQLERRM);
END $$;
SELECT pg_temp.chk('5 time base', 'duty_started flag for crew before sign-in (TB-3)',
  CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='v_crew_legality_ranking' AND column_name='duty_started')
       THEN (SELECT count(*) FROM v_crew_legality_ranking WHERE scenario_id=1 AND duty_started IS FALSE) > 0 END,
  'UI must show "duty starts HH:MMZ" when duty_started = false');

-- ---------------------------------------------------------------------
-- 6. Guardrails (each attempt rolled back)
-- ---------------------------------------------------------------------
DO $$
DECLARE v_agent INT := (SELECT user_id FROM app_user WHERE role_code='AGENT' LIMIT 1);
        v_station INT := (SELECT user_id FROM app_user WHERE role_code='STATION' LIMIT 1);
        v_case INT := (SELECT case_id FROM disruption_case ORDER BY case_id LIMIT 1);
        v_flight BIGINT := (SELECT flight_id FROM flight ORDER BY flight_id LIMIT 1);
        v_dec BIGINT := (SELECT decision_id FROM decision ORDER BY decision_id LIMIT 1);
        msg TEXT;
BEGIN
  BEGIN UPDATE fdp_rule SET max_fdp_min = max_fdp_min + 1 WHERE rule_id = (SELECT min(rule_id) FROM fdp_rule);
        PERFORM pg_temp.chk('6 guardrails','approved FDP rules immutable', FALSE, 'UPDATE succeeded'); RAISE EXCEPTION 'rb';
  EXCEPTION WHEN others THEN IF SQLERRM <> 'rb' THEN PERFORM pg_temp.chk('6 guardrails','approved FDP rules immutable', TRUE, SQLERRM); END IF; END;
  BEGIN UPDATE audit_log SET action='X' WHERE audit_id = (SELECT min(audit_id) FROM audit_log);
        IF FOUND THEN PERFORM pg_temp.chk('6 guardrails','audit log append-only', FALSE, 'UPDATE succeeded'); RAISE EXCEPTION 'rb';
        ELSE PERFORM pg_temp.chk('6 guardrails','audit log append-only', NULL, 'audit_log empty'); END IF;
  EXCEPTION WHEN others THEN IF SQLERRM <> 'rb' THEN PERFORM pg_temp.chk('6 guardrails','audit log append-only', TRUE, SQLERRM); END IF; END;
  BEGIN UPDATE flight_event SET payload='{}' WHERE event_id = (SELECT min(event_id) FROM flight_event);
        PERFORM pg_temp.chk('6 guardrails','flight events immutable', FALSE, 'UPDATE succeeded'); RAISE EXCEPTION 'rb';
  EXCEPTION WHEN others THEN IF SQLERRM <> 'rb' THEN PERFORM pg_temp.chk('6 guardrails','flight events immutable', TRUE, SQLERRM); END IF; END;
  IF v_case IS NOT NULL THEN
    BEGIN INSERT INTO decision (scenario_id, case_id, flight_id, decision_type, rationale, decided_by, decided_role)
          SELECT scenario_id, case_id, v_flight, 'DIVERT', 'agent test', v_agent, 'AGENT' FROM disruption_case WHERE case_id=v_case;
          PERFORM pg_temp.chk('6 guardrails','AI/agent cannot record decisions', FALSE, 'INSERT succeeded'); RAISE EXCEPTION 'rb';
    EXCEPTION WHEN others THEN IF SQLERRM <> 'rb' THEN PERFORM pg_temp.chk('6 guardrails','AI/agent cannot record decisions', TRUE, SQLERRM); END IF; END;
  ELSE PERFORM pg_temp.chk('6 guardrails','AI/agent cannot record decisions', NULL, 'no disruption_case yet (covered in section 7)'); END IF;
  IF v_dec IS NOT NULL THEN
    BEGIN INSERT INTO decision_approval (decision_id, approver_id, approver_role, verdict) VALUES (v_dec, v_station, 'STATION', 'APPROVED');
          PERFORM pg_temp.chk('6 guardrails','station cannot approve', FALSE, 'INSERT succeeded'); RAISE EXCEPTION 'rb';
    EXCEPTION WHEN others THEN IF SQLERRM <> 'rb' THEN PERFORM pg_temp.chk('6 guardrails','station cannot approve', TRUE, SQLERRM); END IF; END;
    BEGIN UPDATE decision SET rationale = 'rewritten' WHERE decision_id = v_dec;
          PERFORM pg_temp.chk('6 guardrails','decision content immutable', FALSE, 'UPDATE succeeded'); RAISE EXCEPTION 'rb';
    EXCEPTION WHEN others THEN IF SQLERRM <> 'rb' THEN PERFORM pg_temp.chk('6 guardrails','decision content immutable', TRUE, SQLERRM); END IF; END;
  ELSE PERFORM pg_temp.chk('6 guardrails','station cannot approve / decision immutable', NULL, 'no decisions yet (covered in section 7)'); END IF;
END $$;

-- ---------------------------------------------------------------------
-- 7. End-to-end flows on a throw-away replay (everything rolled back)
-- ---------------------------------------------------------------------
DO $$
DECLARE
  res JSONB := '[]'; scn INT; cid INT; f BIGINT; rec BIGINT; opt RECORD; dec BIGINT; div BIGINT; rf BIGINT;
  u_occ INT := (SELECT user_id FROM app_user WHERE role_code='OCC' AND is_active LIMIT 1);
  u_disp INT := (SELECT user_id FROM app_user WHERE role_code='DISPATCH' AND is_active LIMIT 1);
  u_agent INT := (SELECT user_id FROM app_user WHERE role_code='AGENT' AND is_active LIMIT 1);
  legs_before INT; legs_after INT; n INT; t0 TIMESTAMPTZ; r RECORD; roles TEXT[];
BEGIN
  BEGIN
    -- pick an SHJ arrival on 21 Nov in the fog window whose crew is LEGAL and LVP-qualified
    SELECT fl.flight_id, fl.sta_utc INTO f, t0 FROM flight fl
      JOIN v_flight_crew_legality cl ON cl.flight_id=fl.flight_id AND cl.scenario_id=1
     WHERE fl.arr_iata='SHJ' AND fl.sta_utc BETWEEN '2026-11-21 01:30Z' AND '2026-11-21 05:00Z' AND cl.crew_status='LEGAL'
       AND (flight_lvp_check(1, fl.flight_id)).not_qualified = '[]'::jsonb
     ORDER BY fl.sta_utc LIMIT 1;
    res := res || jsonb_build_object('c','7.0 pick test flight','ok', f IS NOT NULL,'d', coalesce((SELECT flight_no||' '||dep_iata||'-'||arr_iata||' STA '||to_char(sta_utc,'DD HH24:MI"Z"') FROM flight WHERE flight_id=f),'none'));
    PERFORM set_actor(u_occ);
    scn := clone_scenario(1, 'VALIDATION_' || to_char(clock_timestamp(),'HH24MISSMS'), 'REPLAY');
    UPDATE scenario SET sim_clock_utc = t0 - interval '35 minutes' WHERE scenario_id = scn;
    res := res || jsonb_build_object('c','7.1 clone replay scenario','ok', scn IS NOT NULL,'d','scenario '||scn);
    INSERT INTO disruption_case (scenario_id, title, hub_iata, phase, opened_by) VALUES (scn,'validation','SHJ','RESTRICTED',u_occ) RETURNING case_id INTO cid;
    INSERT INTO case_flight (case_id, flight_id, fog_exposure) VALUES (cid, f, 'HIGH');
    -- feed: airborne, duplicate, late message
    n := 0;
    IF ingest_flight_event(scn,'SIM_FEED','v-1',f,'POSITION',t0 - interval '40 minutes', jsonb_build_object('atd',t0-interval '4 hours','toff',t0-interval '230 minutes','eta',t0)) = 'APPLIED' THEN n:=n+1; END IF;
    IF ingest_flight_event(scn,'SIM_FEED','v-1',f,'POSITION',t0 - interval '40 minutes','{}') = 'DUPLICATE' THEN n:=n+1; END IF;
    IF ingest_flight_event(scn,'SIM_FEED','v-2',f,'POSITION',t0 - interval '60 minutes', jsonb_build_object('eta',t0-interval '10 minutes')) = 'IGNORED_STALE' THEN n:=n+1; END IF;
    res := res || jsonb_build_object('c','7.2 feed: apply / duplicate / out-of-order','ok', n=3,'d', n||'/3 behaved; status '||(SELECT status FROM flight_state WHERE scenario_id=scn AND flight_id=f));
    -- SHJ closed with forecast; alternates open; fuel
    INSERT INTO airport_status_event (scenario_id, iata, op_status, reason, lvp_in_force, arrival_capacity_per_hr, effective_from_utc, expected_reopen_utc, quality, entered_by)
    VALUES (scn,'SHJ','CLOSED','FOG',TRUE,0,t0-interval '50 minutes',t0+interval '90 minutes','FORECAST',u_occ);
    INSERT INTO airport_status_event (scenario_id, iata, op_status, parking_available, weather_above_minima, handling_ok, fuel_ok, effective_from_utc, quality, entered_by)
    SELECT scn, x, 'OPEN', 5, TRUE, TRUE, TRUE, t0-interval '50 minutes', 'MANUAL', u_occ FROM unnest(ARRAY['RKT','FJR']) x;
    INSERT INTO flight_fuel_estimate (scenario_id, flight_id, as_of_utc, est_holding_endurance_min, quality, entered_by)
    VALUES (scn, f, t0-interval '35 minutes', 30, 'ESTIMATED', u_disp);
    res := res || jsonb_build_object('c','7.3 hub/alternate status + fuel recorded','ok', TRUE,'d','SHJ closed (reopen +90 min), RKT/FJR open, 30 min endurance');
    -- legality + recommendation
    n := compute_flight_legality(scn, f, 'validation');
    res := res || jsonb_build_object('c','7.4 legality recomputed','ok', n>0,'d', n||' duty(ies)');
    PERFORM set_actor(coalesce(u_agent,u_occ));
    rec := propose_hold_or_divert(scn, cid, f);
    SELECT * INTO opt FROM recommendation_option WHERE rec_id=rec AND rank=1;
    res := res || jsonb_build_object('c','7.5 engine recommends DIVERT (fuel < reopening)','ok', opt.action='DIVERT' AND opt.is_executable,
      'd', (SELECT rec_type||' '||coalesce(opt.alternate_iata,'')||' conf '||confidence FROM recommendation WHERE rec_id=rec));
    res := res || jsonb_build_object('c','7.6 no time-base errors in options','ok',
      NOT EXISTS (SELECT 1 FROM recommendation_option WHERE rec_id=rec AND blocking_constraints::text LIKE '%TIME_BASE%')
      AND coalesce((SELECT max(crew_margin_min) FROM recommendation_option WHERE rec_id=rec),0) < 14*60,
      'd', 'max crew margin '||coalesce((SELECT max(crew_margin_min) FROM recommendation_option WHERE rec_id=rec),0)||' min');
    -- decision -> approvals (policy aware) -> execute
    PERFORM set_actor(u_disp);
    INSERT INTO decision (scenario_id, case_id, flight_id, rec_id, option_id, decision_type, alternate_iata, followed_recommendation, rationale, decided_by, decided_role)
    VALUES (scn, cid, f, rec, opt.option_id, 'DIVERT', opt.alternate_iata, TRUE, 'validation', u_disp, 'DISPATCH') RETURNING decision_id INTO dec;
    roles := ARRAY['OCC'];
    IF to_regclass('fogops.approval_policy') IS NOT NULL THEN
      SELECT coalesce(array_agg(approver_role), ARRAY['OCC']) INTO roles FROM approval_policy WHERE decision_type='DIVERT' AND required;
    END IF;
    FOR r IN SELECT unnest(roles) AS role LOOP
      PERFORM set_actor((SELECT user_id FROM app_user WHERE role_code=r.role AND is_active LIMIT 1));
      INSERT INTO decision_approval (decision_id, approver_id, approver_role, verdict)
      VALUES (dec, (SELECT user_id FROM app_user WHERE role_code=r.role AND is_active LIMIT 1), r.role, 'APPROVED');
    END LOOP;
    res := res || jsonb_build_object('c','7.7 propose + approve (all required roles)','ok', (SELECT status FROM decision WHERE decision_id=dec)='APPROVED',
      'd', 'roles '||array_to_string(roles,'+')||' -> '||(SELECT status FROM decision WHERE decision_id=dec));
    SELECT count(*) INTO legs_before FROM crew_duty_leg WHERE scenario_id=scn AND duty_id IN (SELECT duty_id FROM crew_duty_leg WHERE scenario_id=scn AND flight_id=f);
    PERFORM set_actor(u_occ);
    div := execute_diversion(dec);
    SELECT recovery_flight_id INTO rf FROM diversion WHERE diversion_id=div;
    SELECT count(*) INTO legs_after FROM crew_duty_leg WHERE scenario_id=scn AND duty_id IN (SELECT duty_id FROM crew_duty_leg WHERE scenario_id=scn AND flight_id=f);
    res := res || jsonb_build_object('c','7.8 execute diversion: recovery flight + extra sector','ok',
      rf IS NOT NULL AND legs_after > legs_before AND (SELECT status FROM decision WHERE decision_id=dec)='EXECUTED',
      'd', (SELECT flight_no||' '||dep_iata||'-'||arr_iata FROM flight WHERE flight_id=rf)||', legs '||legs_before||'->'||legs_after);
    res := res || jsonb_build_object('c','7.9 latest legal departure from alternate','ok',
      EXISTS (SELECT 1 FROM latest_departure_calc WHERE scenario_id=scn AND flight_id=rf AND is_current AND latest_legal_offblocks_utc IS NOT NULL),
      'd', coalesce((SELECT 'latest '||to_char(latest_legal_offblocks_utc,'DD HH24:MI"Z"')||', target '||to_char(operational_target_utc,'HH24:MI"Z"')||', '||status
                FROM latest_departure_calc WHERE scenario_id=scn AND flight_id=rf AND is_current LIMIT 1),'none'));
    IF to_regclass('fogops.integration_outbox') IS NOT NULL THEN
      res := res || jsonb_build_object('c','7.10 aeroMart outbox entry queued','ok', EXISTS (SELECT 1 FROM integration_outbox WHERE decision_id=dec), 'd', '');
    END IF;
    -- Q1..Q4
    res := res || jsonb_build_object('c','7.11 Q1 crew ranking view','ok', EXISTS (SELECT 1 FROM v_crew_legality_ranking WHERE scenario_id=scn), 'd', '');
    res := res || jsonb_build_object('c','7.12 Q2 aircraft whereabouts','ok',
      EXISTS (SELECT 1 FROM v_aircraft_whereabouts WHERE scenario_id=scn AND registration=(SELECT registration FROM flight_state WHERE scenario_id=scn AND flight_id=f)),
      'd', coalesce((SELECT position_text||' / waiting for '||waiting_for FROM v_aircraft_whereabouts WHERE scenario_id=scn AND registration=(SELECT registration FROM flight_state WHERE scenario_id=scn AND flight_id=f)),'none'));
    res := res || jsonb_build_object('c','7.13 Q3 flight watch shows latest legal departure','ok',
      EXISTS (SELECT 1 FROM v_flight_watch WHERE case_id=cid AND flight_id=f AND latest_legal_offblocks_utc IS NOT NULL), 'd', '');
    SELECT count(*) INTO n FROM standby_candidates(scn, (SELECT duty_id FROM crew_duty_leg WHERE scenario_id=scn AND flight_id=rf LIMIT 1), 'CP',
      (SELECT alternate_iata FROM diversion WHERE diversion_id=div), (SELECT leg_seq FROM crew_duty_leg WHERE scenario_id=scn AND flight_id=rf LIMIT 1));
    res := res || jsonb_build_object('c','7.14 Q4 standby candidates','ok', n > 0, 'd', n||' candidates (any verdict)');
    IF EXISTS (SELECT 1 FROM pg_proc WHERE proname='downstream_impact') THEN
      SELECT count(*) INTO n FROM downstream_impact(scn, f);
      res := res || jsonb_build_object('c','7.15 downstream impact (aircraft + crew)','ok', n > 0, 'd', n||' rows');
    END IF;
    -- reopening -> recovery plan -> report
    UPDATE scenario SET sim_clock_utc = t0 + interval '90 minutes' WHERE scenario_id = scn;
    INSERT INTO airport_status_event (scenario_id, iata, op_status, lvp_in_force, arrival_capacity_per_hr, effective_from_utc, quality, entered_by)
    VALUES (scn,'SHJ','OPEN',TRUE,12,t0+interval '90 minutes','MEASURED',u_occ);
    n := build_recovery_plan(scn, cid, 60);
    res := res || jsonb_build_object('c','7.16 recovery plan','ok', EXISTS (SELECT 1 FROM recovery_plan_item WHERE plan_id=n),
      'd', (SELECT count(*) FROM recovery_plan_item WHERE plan_id=n)||' items, '||coalesce((SELECT arrivals_in_window FROM recovery_plan WHERE plan_id=n),0)||' in window');
    n := generate_report(cid, u_occ);
    res := res || jsonb_build_object('c','7.17 report generated','ok', (SELECT jsonb_array_length(content->'decisions') FROM report WHERE report_id=n) >= 1, 'd', '');
    res := res || jsonb_build_object('c','7.18 shared timeline has audit + feed','ok',
      (SELECT count(DISTINCT stream) FROM v_case_timeline WHERE case_id=cid) >= 3, 'd', (SELECT string_agg(DISTINCT stream, ',') FROM v_case_timeline WHERE case_id=cid));
    res := res || jsonb_build_object('c','7.19 LIVE untouched by replay','ok',
      NOT EXISTS (SELECT 1 FROM crew_duty_leg WHERE scenario_id=1 AND leg_source<>'PLANNED'), 'd', '');
    RAISE EXCEPTION 'validation_rollback';
  EXCEPTION WHEN others THEN
    IF SQLERRM <> 'validation_rollback' THEN res := res || jsonb_build_object('c','7.x flow aborted','ok',FALSE,'d',SQLERRM); END IF;
  END;
  INSERT INTO vr(area, check_name, status, detail)
  SELECT '7 flows', e->>'c', CASE WHEN (e->>'ok')::boolean THEN 'PASS' ELSE 'FAIL' END, e->>'d' FROM jsonb_array_elements(res) e;
END $$;

-- ---------------------------------------------------------------------
-- Report
-- ---------------------------------------------------------------------
\echo
\echo '================ SUMMARY ================'
SELECT status, count(*) FROM vr GROUP BY 1 ORDER BY CASE status WHEN 'FAIL' THEN 0 WHEN 'WARN' THEN 1 WHEN 'SKIP' THEN 2 ELSE 3 END;
\echo '================ FAIL / WARN ================'
SELECT area, check_name, status, left(detail, 160) AS detail FROM vr WHERE status IN ('FAIL','WARN','SKIP') ORDER BY id;
\echo '================ ALL CHECKS ================'
SELECT area, check_name, status, left(detail, 120) AS detail FROM vr ORDER BY id;
