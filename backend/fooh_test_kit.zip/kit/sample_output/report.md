# FOOH end-to-end smoke test

- URL: http://127.0.0.1:8099/fogops_app_mockup_v2.html
- Run at: 2026-11-21 12:29:12
- Page load: 756 ms · API calls seen: 0 · console errors: 48 · failed requests: 0 (+47 third-party)
- Result: **2 FAIL · 1 WARN · 0 INFO · 4 PASS**

## Findings

| Severity | Area | Finding | Detail |
|---|---|---|---|
| FAIL | flow | flow '04_expected_failure_demo' failed at step 1 (expect_text) | Locator.wait_for: Timeout 1500ms exceeded. |
| FAIL | flow | flow '04_expected_failure_demo' failed |  |
| WARN | network | 47 third-party resources failed to load (fonts/CDN). Fine offline; check fallbacks | fonts.googleapis.com |
| PASS | availability | home page loaded in 756 ms |  |
| PASS | flow | flow '01_board_loads' passed |  |
| PASS | flow | flow '02_open_flight_preview_cancel' passed |  |
| PASS | flow | flow '03_approve_g9472_as_occ' passed |  |

## Steps

| Step | Result |
|---|---|
| open flight G9464 | ok |
| open flight G9472 | ok |
| open flight G9621 | ok |
| click 'Approvals' | ok |
| click '🔔' | ok |
| click 'Ask' | ok |
| click 'Since you last looked' | ok |
| click 'OCC' | ok |
| click 'Dispatch' | ok |
| click 'Crew Control' | ok |
| click 'Station' | ok |
| click 'Recovery' | ok |
| click 'Rules & filters' | ok |
| click 'Integrations' | ok |
| click 'What if…' | ok |
| click 'Report' | ok |
| click 'Data sources' | ok |
| click 'Theme' | ok |
| click '7' | ok |
| click '961' | ok |
| click '3' | ok |
| click '1' | ok |
| click '7 min' | ok |
| click '2 / 2' | ok |
| click '2' | ok |
| click 'Pilots not LVP-qualified' | ok |
| click 'Crew at risk' | ok |
| click 'Needs verification' | ok |
| click 'Waiting for approval' | ok |
| click 'Watched by me' | ok |
| click 'Clear' | ok |
| click 'Close' | ok |
| click '👁 Watching + Teams' | not clickable: Locator.click: Timeout 2500ms exceeded. |
| click 'Stop Teams alerts' | not clickable: Locator.click: Timeout 2500ms exceeded. |
| click 'Open in aeroOps ↗' | ok |
| click 'Open in Crew system ↗' | ok |
| click 'Open in aeroMart ↗' | ok |
| click 'Execute decision' | not clickable: Locator.click: Timeout 2500ms exceeded. |
| click '#1' | not clickable: Locator.click: Timeout 2500ms exceeded. |
| click '#2' | not clickable: Locator.click: Timeout 2500ms exceeded. |
| click 'Ask stations' | ok |
| click 'Why this time?' | ok |
| click 'Post' | ok |
| [01_board_loads] 1. expect_text Act now | ok |
| [01_board_loads] 2. expect_text Approvals | ok |
| [02_open_flight_preview_cancel] 1. click_text G9455 | ok |
| [02_open_flight_preview_cancel] 2. click_role Propose: Divert to FJR | ok |
| [02_open_flight_preview_cancel] 3. expect_text What will happen | ok |
| [02_open_flight_preview_cancel] 4. expect_text Approvals required | ok |
| [02_open_flight_preview_cancel] 5. click_role Cancel | ok |
| [03_approve_g9472_as_occ] 1. click_text G9472 | ok |
| [03_approve_g9472_as_occ] 2. click_role Review and approve as OCC | ok |
| [03_approve_g9472_as_occ] 3. click_role Approve | ok |
| [03_approve_g9472_as_occ] 4. expect_text Waiting for Crew Control | ok |
| [04_expected_failure_demo] 1. expect_text | FAILED: Locator.wait_for: Timeout 1500ms exceeded. |

## Console / page errors (first 20)

- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: the server responded with a status of 404 (File not found)
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
- `error` Failed to load resource: net::ERR_NAME_NOT_RESOLVED
