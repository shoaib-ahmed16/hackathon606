#!/usr/bin/env python3
"""
FOOH / FogOps end-to-end smoke test (black-box, works without knowing the app's code).

  pip install playwright && python -m playwright install chromium
  python e2e_smoke.py --url http://130.61.182.207:8080/ --out results            # read-only exploration
  python e2e_smoke.py --url ... --flows flows.json --allow-writes                   # + scripted demo flows

What it does
  1. Loads the app (desktop + mobile), timing, console errors, page errors, failed/4xx/5xx requests.
  2. Records every XHR/fetch call (method, status, latency, size) and re-probes same-origin GET APIs:
     JSON validity, latency, timestamps without a timezone (time-base rule TB-5).
  3. Scans visible text for data/time bugs seen before:
       - "NaN", "undefined", "null", "Invalid Date", "[object Object]"
       - crew margins > 12 h  ("margin 963 min")         -> clock / time-base bug (TB-1/TB-2)
       - "N h M min left" > 13 h                          -> crew time counted before sign-in (TB-3)
       - the same flight number + route shown twice      -> duplicate flight rows
       - "passed N min ago" next to large fuel/crew values -> inconsistent clocks
  4. Explores the UI: clicks tabs/buttons/links (skips write actions unless --allow-writes),
     records errors per click, takes screenshots.
  5. Optional scripted flows (flows.json): click/fill/expect steps for the demo path.
  6. Writes results/report.md, results.json, api_calls.csv and screenshots/.
"""
import argparse, csv, json, os, re, sys, time
from urllib.parse import urlparse

from playwright.sync_api import sync_playwright

WRITE_WORDS = re.compile(r"\b(approve|execute|reject|propose|submit|delete|save|confirm|send|post|divert|accept|apply|"
                         r"cancel flight|revoke|swap|call out|mark|enter answer|reset)\b", re.I)
BAD_TEXT = re.compile(r"\bNaN\b|\bundefined\b|Invalid Date|\[object Object\]|\bnull\b(?!\s*(island|hypothesis))")
NAIVE_TS = re.compile(r'"(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?)"')
FLIGHT_ROUTE = re.compile(r"\b((?:G9|3O|E5|9P|3L)\d{2,4}[A-Z]?)\b[\s\S]{0,40}?\b([A-Z]{3})\s*(?:→|->|-|–)\s*([A-Z]{3})\b")


def now_ms():
    return int(time.time() * 1000)


class Run:
    def __init__(self, out):
        self.out = out
        os.makedirs(os.path.join(out, "screenshots"), exist_ok=True)
        self.findings = []        # (severity, area, message, detail)
        self.api = []
        self.console = []
        self.failed = []
        self.steps = []

    def add(self, sev, area, msg, detail=""):
        self.findings.append({"severity": sev, "area": area, "message": msg, "detail": str(detail)[:600]})

    def shot(self, page, name, full=False):
        path = os.path.join(self.out, "screenshots", re.sub(r"[^a-zA-Z0-9_.-]+", "_", name)[:80] + ".png")
        try:
            page.screenshot(path=path, full_page=full)
        except Exception as e:  # noqa
            self.add("WARN", "screenshot", f"could not capture {name}", e)
        return path


def attach_listeners(page, run, origin):
    def on_console(msg):
        if msg.type in ("error", "warning"):
            run.console.append({"type": msg.type, "text": msg.text[:500], "url": page.url})

    def on_pageerror(err):
        run.console.append({"type": "pageerror", "text": str(err)[:500], "url": page.url})

    def on_requestfailed(req):
        run.failed.append({"url": req.url, "method": req.method, "failure": (req.failure or "")[:200],
                           "third_party": urlparse(req.url).netloc != origin})

    def on_response(resp):
        req = resp.request
        if req.resource_type in ("xhr", "fetch") or resp.status >= 400:
            timing = req.timing or {}
            dur = timing.get("responseEnd", -1)
            try:
                size = len(resp.body()) if resp.status < 400 and req.resource_type in ("xhr", "fetch") else 0
            except Exception:
                size = 0
            run.api.append({"method": req.method, "url": resp.url, "status": resp.status, "ms": round(dur, 1) if dur else -1,
                            "type": req.resource_type, "bytes": size, "same_origin": urlparse(resp.url).netloc == origin})

    page.on("console", on_console)
    page.on("pageerror", on_pageerror)
    page.on("requestfailed", on_requestfailed)
    page.on("response", on_response)


ROW_JS = """() => {
  const sel = 'tr,[role=row],[role=option],[class*="row"],[class*="Row"],[class*="card"],[class*="Card"],li';
  const all = [...document.querySelectorAll(sel)].filter(e => e.offsetParent !== null);
  const leaf = all.filter(e => !all.some(o => o !== e && e.contains(o)));
  return leaf.map(e => (e.innerText || '').slice(0, 300));
}"""


def rows(page):
    try:
        return page.evaluate(ROW_JS)
    except Exception:
        return []


def visible_text(page):
    try:
        return page.evaluate("() => document.body ? document.body.innerText : ''")
    except Exception:
        return ""


def scan_text(run, text, where, rows_text=None):
    for m in set(BAD_TEXT.findall(text)):
        run.add("FAIL", "data display", f"'{m}' shown on screen", where)
    for m in re.finditer(r"margin[^0-9]{0,20}(\d{3,5})\s*min", text, re.I):
        if int(m.group(1)) > 720:
            run.add("FAIL", "time base", f"crew/fuel margin {m.group(1)} min (> 12 h): likely evaluated at the wrong clock (TB-1/TB-2)",
                    text[max(0, m.start() - 120): m.end() + 60].replace("\n", " "))
    for m in re.finditer(r"(\d{1,2})\s*h\s*(\d{1,2})\s*(?:min)?\s*left", text, re.I):
        if int(m.group(1)) >= 13:
            run.add("WARN", "time base", f"'{m.group(0)}': crew time > 13 h. Check the duty has started (TB-3)",
                    text[max(0, m.start() - 120): m.end() + 40].replace("\n", " "))
    for m in re.finditer(r"passed\s+\d+\s*min", text, re.I):
        ctx = text[max(0, m.start() - 250): m.end()]
        if re.search(r"(\d{3,4})\s*min\*?", ctx) and re.search(r"\b1\d h|\b[2-9]\d? h \d+ (?:min )?left", ctx):
            run.add("WARN", "time base", "deadline 'passed' while fuel/crew show many hours left: mixed clocks?", ctx.replace("\n", " ")[-300:])
    if rows_text:
        seen = {}
        for rt in rows_text:
            m = FLIGHT_ROUTE.search(rt)
            if m:
                key = (m.group(1), m.group(2), m.group(3))
                seen[key] = seen.get(key, 0) + 1
        dups = {k: v for k, v in seen.items() if v > 1}
        if dups:
            run.add("WARN", "data", f"same flight+route in more than one list row on {where} (duplicate flights, or several days shown without a date?)",
                    ", ".join(f"{k[0]} {k[1]}-{k[2]} x{v}" for k, v in list(dups.items())[:12]))


def check_layout(run, page, label):
    try:
        ov = page.evaluate("() => ({sw: document.documentElement.scrollWidth, w: window.innerWidth})")
        if ov["sw"] > ov["w"] + 8:
            run.add("WARN", "layout", f"horizontal overflow on {label}: page {ov['sw']}px wide in a {ov['w']}px viewport")
        a11y = page.evaluate("""() => ({
            imgs: [...document.images].filter(i => !i.alt).length,
            btns: [...document.querySelectorAll('button')].filter(b => !(b.innerText||'').trim() && !b.getAttribute('aria-label') && !b.title).length,
            inputs: [...document.querySelectorAll('input,select,textarea')].filter(i => !i.labels?.length && !i.getAttribute('aria-label') && !i.placeholder).length })""")
        if a11y["btns"]:
            run.add("WARN", "accessibility", f"{a11y['btns']} buttons without a name on {label}")
        if a11y["inputs"]:
            run.add("INFO", "accessibility", f"{a11y['inputs']} form fields without a label on {label}")
    except Exception as e:
        run.add("WARN", "layout", f"layout check failed on {label}", e)


def explore(run, page, base, allow_writes, max_clicks):
    sel = "button:visible, [role=tab]:visible, [role=button]:visible, nav a:visible, a[href^='/']:visible, a[href^='#']:visible"
    handles = page.locator(sel)
    n = min(handles.count(), 400)
    labels, seen = [], set()
    for i in range(n):
        try:
            t = (handles.nth(i).inner_text(timeout=500) or handles.nth(i).get_attribute("aria-label") or "").strip().split("\n")[0][:60]
        except Exception:
            continue
        if not t or t in seen:
            continue
        seen.add(t)
        labels.append(t)
    clicked = 0
    for t in labels:
        if clicked >= max_clicks:
            break
        if WRITE_WORDS.search(t) and not allow_writes:
            run.steps.append({"step": f"click '{t}'", "result": "skipped (write action)"})
            continue
        before_c, before_f = len(run.console), len([a for a in run.api if a["status"] >= 400])
        t0 = now_ms()
        try:
            page.locator(sel).filter(has_text=t).first.click(timeout=2500)
            page.wait_for_timeout(700)
            res = "ok"
        except Exception as e:
            res = "not clickable: " + str(e).split("\n")[0][:120]
        new_err = run.console[before_c:]
        new_http = [a for a in run.api if a["status"] >= 400][before_f:]
        if new_err:
            run.add("FAIL", "ui", f"console/page error after clicking '{t}'", new_err[0]["text"])
        if new_http:
            run.add("FAIL", "api", f"HTTP {new_http[0]['status']} after clicking '{t}'", new_http[0]["url"])
        run.steps.append({"step": f"click '{t}'", "result": res, "ms": now_ms() - t0, "errors": len(new_err) + len(new_http)})
        if res == "ok":
            clicked += 1
            run.shot(page, f"click_{clicked:02d}_{t}")
            scan_text(run, visible_text(page), f"after '{t}'")
        page.keyboard.press("Escape")
        page.goto(base, wait_until="networkidle")   # SPA views don't change the URL: reset after every click
    return clicked


def click_flight_rows(run, page, k=3):
    text = visible_text(page)
    flights = []
    for m in re.finditer(r"\b((?:G9|3O|E5|9P|3L)\d{2,4})\b", text):
        if m.group(1) not in flights:
            flights.append(m.group(1))
    for fno in flights[:k]:
        try:
            page.get_by_text(fno, exact=True).first.click(timeout=2000)
            page.wait_for_timeout(800)
            run.shot(page, f"flight_{fno}")
            scan_text(run, visible_text(page), f"flight {fno} detail")
            run.steps.append({"step": f"open flight {fno}", "result": "ok"})
        except Exception as e:
            run.steps.append({"step": f"open flight {fno}", "result": "failed: " + str(e).split("\n")[0][:100]})
            run.add("WARN", "ui", f"could not open flight {fno} by clicking its number")
        page.keyboard.press("Escape")


def probe_apis(run, ctx, origin):
    gets = sorted({a["url"] for a in run.api if a["method"] == "GET" and a["same_origin"] and a["type"] in ("xhr", "fetch")})
    for url in gets[:60]:
        t0 = now_ms()
        try:
            r = ctx.request.get(url, timeout=15000)
            ms = now_ms() - t0
            body = r.text()
            if r.status >= 400:
                run.add("FAIL", "api", f"GET {urlparse(url).path} -> {r.status}", body[:200])
                continue
            if ms > 1500:
                run.add("WARN", "performance", f"GET {urlparse(url).path} took {ms} ms")
            if "json" in (r.headers.get("content-type") or ""):
                try:
                    json.loads(body)
                except Exception:
                    run.add("FAIL", "api", f"invalid JSON from {urlparse(url).path}")
                naive = [m for m in NAIVE_TS.findall(body) if not re.search(r"(Z|[+-]\d{2}:?\d{2})$", m)]
                if naive:
                    run.add("WARN", "time base", f"{urlparse(url).path} returns timestamps without timezone ({len(naive)}), e.g. {naive[0]}",
                            "Send ISO-8601 UTC with 'Z' (TB-5)")
        except Exception as e:
            run.add("WARN", "api", f"probe failed for {url}", e)


def run_flows(run, page, flows_path, base):
    flows = json.load(open(flows_path))
    for flow in flows:
        name = flow["name"]
        ok = True
        page.goto(base, wait_until="networkidle")      # every flow starts from a clean load
        for i, st in enumerate(flow["steps"], 1):
            act = st["action"]
            try:
                if act == "goto":
                    page.goto(st["url"], wait_until="networkidle")
                elif act == "click_text":
                    page.get_by_text(st["text"], exact=st.get("exact", False)).first.click(timeout=st.get("timeout", 5000))
                elif act == "click_role":
                    page.get_by_role(st["role"], name=st["name"], exact=st.get("exact", True)).first.click(timeout=st.get("timeout", 5000))
                elif act == "click_selector":
                    page.locator(st["selector"]).first.click(timeout=st.get("timeout", 5000))
                elif act == "fill":
                    page.locator(st["selector"]).first.fill(st["value"])
                elif act == "expect_text":
                    page.get_by_text(st["text"], exact=st.get("exact", False)).first.wait_for(timeout=st.get("timeout", 8000))
                elif act == "expect_no_text":
                    if page.get_by_text(st["text"], exact=st.get("exact", False)).count():
                        raise AssertionError(f"unexpected text '{st['text']}'")
                elif act == "wait":
                    page.wait_for_timeout(st.get("ms", 1000))
                elif act == "press":
                    page.keyboard.press(st["key"])
                page.wait_for_timeout(st.get("settle_ms", 400))
                run.steps.append({"step": f"[{name}] {i}. {act} {st.get('text') or st.get('selector') or st.get('name') or st.get('url') or ''}", "result": "ok"})
            except Exception as e:
                ok = False
                run.shot(page, f"flow_FAIL_{name}_{i}", full=True)
                run.steps.append({"step": f"[{name}] {i}. {act}", "result": "FAILED: " + str(e).split("\n")[0][:160]})
                run.add("FAIL", "flow", f"flow '{name}' failed at step {i} ({act})", str(e).split("\n")[0])
                break
        run.shot(page, f"flow_{name}_end", full=True)
        scan_text(run, visible_text(page), f"flow {name}")
        run.add("PASS" if ok else "FAIL", "flow", f"flow '{name}' {'passed' if ok else 'failed'}")


def write_report(run, meta):
    sev_order = {"FAIL": 0, "WARN": 1, "INFO": 2, "PASS": 3}
    run.findings.sort(key=lambda f: sev_order.get(f["severity"], 9))
    with open(os.path.join(run.out, "results.json"), "w") as fh:
        json.dump({"meta": meta, "findings": run.findings, "steps": run.steps, "console": run.console,
                   "failed_requests": run.failed, "api_calls": run.api}, fh, indent=2, default=str)
    with open(os.path.join(run.out, "api_calls.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["method", "url", "status", "ms", "type", "bytes", "same_origin"])
        w.writeheader()
        w.writerows(run.api)
    counts = {s: sum(1 for f in run.findings if f["severity"] == s) for s in ("FAIL", "WARN", "INFO", "PASS")}
    lines = [f"# FOOH end-to-end smoke test", "", f"- URL: {meta['url']}", f"- Run at: {meta['started']}",
             f"- Page load: {meta.get('load_ms')} ms · API calls seen: {len(run.api)} · console errors: "
             f"{sum(1 for c in run.console if c['type'] in ('error', 'pageerror'))} · failed requests: "
             f"{sum(1 for f in run.failed if not f['third_party'])} (+{sum(1 for f in run.failed if f['third_party'])} third-party)",
             f"- Result: **{counts['FAIL']} FAIL · {counts['WARN']} WARN · {counts['INFO']} INFO · {counts['PASS']} PASS**", "",
             "## Findings", "", "| Severity | Area | Finding | Detail |", "|---|---|---|---|"]
    for f in run.findings:
        lines.append(f"| {f['severity']} | {f['area']} | {f['message'].replace('|', '/')} | {f['detail'].replace('|', '/').replace(chr(10), ' ')[:220]} |")
    lines += ["", "## Steps", "", "| Step | Result |", "|---|---|"]
    lines += [f"| {s['step'].replace('|', '/')} | {s['result'].replace('|', '/')} |" for s in run.steps]
    slow = sorted([a for a in run.api if a["ms"] and a["ms"] > 0], key=lambda a: -a["ms"])[:10]
    if slow:
        lines += ["", "## Slowest API calls", "", "| ms | status | method | url |", "|---|---|---|---|"]
        lines += [f"| {a['ms']} | {a['status']} | {a['method']} | {a['url'][:120]} |" for a in slow]
    if run.console:
        lines += ["", "## Console / page errors (first 20)", ""] + [f"- `{c['type']}` {c['text'][:200]}" for c in run.console[:20]]
    open(os.path.join(run.out, "report.md"), "w").write("\n".join(lines) + "\n")
    return counts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--out", default="results")
    ap.add_argument("--flows", help="JSON file with scripted flows (see flows.example.json)")
    ap.add_argument("--allow-writes", action="store_true", help="allow clicking approve/propose/execute etc. Use on a demo copy!")
    ap.add_argument("--max-clicks", type=int, default=40)
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--chromium", help="path to a chromium binary (optional)")
    a = ap.parse_args()
    run = Run(a.out)
    origin = urlparse(a.url).netloc
    meta = {"url": a.url, "started": time.strftime("%Y-%m-%d %H:%M:%S"), "allow_writes": a.allow_writes}
    with sync_playwright() as p:
        kw = {"headless": not a.headed, "args": ["--no-sandbox"]}
        if a.chromium:
            kw["executable_path"] = a.chromium
        browser = p.chromium.launch(**kw)
        ctx = browser.new_context(viewport={"width": 1600, "height": 1000})
        page = ctx.new_page()
        attach_listeners(page, run, origin)
        t0 = now_ms()
        try:
            resp = page.goto(a.url, wait_until="networkidle", timeout=45000)
            meta["load_ms"] = now_ms() - t0
            meta["http_status"] = resp.status if resp else None
            if not resp or resp.status >= 400:
                run.add("FAIL", "availability", f"home page returned {resp.status if resp else 'no response'}")
            else:
                run.add("PASS", "availability", f"home page loaded in {meta['load_ms']} ms")
            if meta["load_ms"] > 4000:
                run.add("WARN", "performance", f"home page took {meta['load_ms']} ms to settle")
        except Exception as e:
            run.add("FAIL", "availability", "home page did not load", e)
            write_report(run, meta)
            print(open(os.path.join(a.out, "report.md")).read())
            sys.exit(2)
        meta["title"] = page.title()
        run.shot(page, "00_home", full=True)
        txt = visible_text(page)
        scan_text(run, txt, "home", rows(page))
        check_layout(run, page, "desktop home")
        click_flight_rows(run, page)
        explore(run, page, a.url, a.allow_writes, a.max_clicks)
        if a.flows:
            page.goto(a.url, wait_until="networkidle")
            run_flows(run, page, a.flows, a.url)
        probe_apis(run, ctx, origin)
        m = browser.new_context(viewport={"width": 420, "height": 900}, is_mobile=True)
        mp = m.new_page()
        attach_listeners(mp, run, origin)
        mp.goto(a.url, wait_until="networkidle")
        run.shot(mp, "zz_mobile_home")
        check_layout(run, mp, "mobile home")
        browser.close()
    third = [f for f in run.failed if f["third_party"]]
    errs = [c for c in run.console if c["type"] in ("error", "pageerror")]
    res_errs = [c for c in errs if c["text"].startswith("Failed to load resource")]
    real = [c for c in errs if not c["text"].startswith("Failed to load resource")]
    if third and res_errs and not [f for f in run.failed if not f["third_party"]]:
        run.add("WARN", "network", f"{len(third)} third-party resources failed to load (fonts/CDN). Fine offline; check fallbacks",
                ", ".join(sorted({urlparse(f['url']).netloc for f in third})))
    elif res_errs:
        real += res_errs
    if real:
        run.add("FAIL", "console", f"{len(real)} console/page errors", real[0]["text"])
    own_failed = [f for f in run.failed if not f["third_party"]]
    if own_failed:
        run.add("FAIL", "network", f"{len(own_failed)} failed requests to the app's own server", own_failed[0]["url"])
    http_err = [x for x in run.api if x["status"] >= 400 and x["same_origin"]]
    if http_err:
        run.add("FAIL", "api", f"{len(http_err)} HTTP errors from the app's API", f"{http_err[0]['status']} {http_err[0]['url']}")
    counts = write_report(run, meta)
    print(f"Done: {counts}. Report: {os.path.join(a.out, 'report.md')}")
    sys.exit(1 if counts["FAIL"] else 0)


if __name__ == "__main__":
    main()
