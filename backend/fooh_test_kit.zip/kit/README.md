# FOOH end-to-end test kit

Black-box tests for the live app, plus database validation. Read `DEMO_READINESS.md` first.

## 1. Database validation (read-only: every write test is rolled back)
```bash
psql "postgresql://USER@HOST:5432/fogops" -f db/db_validation.sql > db_validation_report.txt
```
66 checks in 7 areas:

1. structure;
2. reference data and organizer rules;
3. data integrity (duplicates, wrong-day legs, pax direction, roster timezone);
4. legality reference cases;
5. time base;
6. guardrails;
7. an end-to-end flow on a throw-away replay: feed → recommendation → approvals → execute → Q1–Q4 → downstream → recovery → report → timeline.

Expected: **0 FAIL**.

## 2. Browser end-to-end test
```bash
pip install playwright && python -m playwright install chromium
python ui/e2e_smoke.py --url http://130.61.182.207:8080/ --out results                       # read-only
python ui/e2e_smoke.py --url ... --flows ui/flows.example.json --allow-writes --out results   # + scripted flows (demo copy only!)
```
Output: `results/report.md`, `results.json`, `api_calls.csv` and `screenshots/`. The exit code is 1 if anything FAILs.

The tool:
- detects console errors, HTTP errors, slow APIs and timestamps without a timezone;
- detects NaN/undefined on screen, 900+ minute margins, crew countdowns > 13 h and duplicate flight rows;
- checks for horizontal overflow on mobile and unnamed buttons.

Adapt `ui/flows.example.json` to your app's labels. The step types are:

| Step | Meaning |
|---|---|
| `goto` | Open a URL |
| `click_text` | Click an element by its text |
| `click_role` | Click by role and exact name |
| `click_selector` | Click by CSS selector |
| `fill` | Type a value into a field |
| `expect_text` / `expect_no_text` | Check text is / isn't on screen |
| `wait` | Pause |
| `press` | Press a key |

`sample_output/` is a self-test run against the v2 mockup. Flow 04 fails on purpose, to show what a failure looks like.
